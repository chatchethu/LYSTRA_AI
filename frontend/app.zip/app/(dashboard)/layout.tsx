"use client";

import { Sidebar } from "@/components/layout/Sidebar";
import { ConversationProvider, useConversation } from "@/components/chat/ConversationProvider";

function DashboardLayoutInner({ children }: { children: React.ReactNode }) {
  const { conversationId, setConversationId } = useConversation();
  
  return (
    <div className="flex h-screen overflow-hidden bg-[#0a0a0a]">
      <Sidebar
        currentConversationId={conversationId}
        onSelectConversation={setConversationId}
      />
      <main className="flex-1 flex flex-col h-full overflow-hidden relative">
        {children}
      </main>
    </div>
  );
}

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <ConversationProvider>
      <DashboardLayoutInner>{children}</DashboardLayoutInner>
    </ConversationProvider>
  );
}
