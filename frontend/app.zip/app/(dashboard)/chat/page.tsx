"use client";

import { useState, useRef, useEffect, useCallback } from "react";
import { Send, Paperclip, Mic, Sparkles, PanelLeft } from "lucide-react";
import { MessageList } from "@/components/chat/message";
import { useAuth } from "@/components/auth/AuthProvider";
import { AuthModal } from "@/components/auth/AuthModal";
import { useConversation } from "@/components/chat/ConversationProvider";
import { parseNovaEvent } from "@/lib/novaResponseParser";
import clsx from "clsx";

export default function ChatPage() {
  const { conversationId, setConversationId } = useConversation();

  const [input, setInput] = useState("");
  const [isRecording, setIsRecording] = useState(false);
  const [messages, setMessages] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [guestCount, setGuestCount] = useState(0);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [streamingResponseType, setStreamingResponseType] = useState("explanation");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const isStreamingRef = useRef(false);
  // After streaming completes, block exactly one DB reload from the conversationId effect
  // to prevent the saved message being appended on top of the already-rendered stream.
  const justStreamedRef = useRef(false);

  const { isAuthenticated, token, user, logout, isAuthLoaded, getValidToken } = useAuth();

  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Load messages when conversationId changes — but only AFTER auth has hydrated from localStorage
  useEffect(() => {
    if (!isAuthLoaded) return;
    // CRITICAL FIX: If we are actively streaming a new response and the backend assigns us a new conversation_id,
    // do NOT reload from the DB. The DB only has the user message at this point, which would overwrite our state.
    if (isStreamingRef.current) return;
    // After streaming finishes, skip exactly one reload to prevent the DB message
    // being appended on top of the already-rendered streamed content.
    if (justStreamedRef.current) {
      justStreamedRef.current = false;
      return;
    }

    const loadConversation = async () => {
      if (!conversationId || !isAuthenticated) {
        if (!conversationId && isAuthLoaded) {
          setMessages([{ role: "assistant" as const, content: "Hey! 👋 What's up?" }]);
        }
        return;
      }
      setIsLoading(true);
      try {
        const validToken = await getValidToken();
        if (!validToken) { logout(); return; }

        const res = await fetch(`http://localhost:8000/api/conversations/${conversationId}/messages`, {
          headers: { "Authorization": `Bearer ${validToken}` }
        });
        if (res.status === 401) { logout(); return; }
        if (res.status === 404 || res.status === 403) { setConversationId(null); return; }
        if (res.ok) {
          const data = await res.json();
          const formatted = data.map((m: any) => {
            let blocks;
            if (m.role === "assistant") {
              try {
                const parsed = JSON.parse(m.content);
                if (parsed.blocks) blocks = parsed.blocks;
              } catch(e) {}
            }
            return {
              role: m.role,
              content: m.content,
              blocks: blocks,
              timestamp: new Date(m.created_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
            };
          });
          setMessages(formatted.length > 0 ? formatted : [{ role: "assistant" as const, content: "Hey! 👋 What's up?" }]);
        }
      } catch (e) {
        console.error("Failed to load conversation", e);
      } finally {
        setIsLoading(false);
      }
    };
    loadConversation();
  }, [conversationId, isAuthenticated, isAuthLoaded]);

  // Guest count
  useEffect(() => {
    if (!isAuthenticated) {
      const stored = localStorage.getItem("nova_guest_count");
      if (stored) setGuestCount(parseInt(stored, 10));
    }
  }, [isAuthenticated]);

  // Listen for "show auth modal" events from Sidebar
  useEffect(() => {
    const handler = () => setShowAuthModal(true);
    window.addEventListener("show-auth-modal", handler);
    return () => window.removeEventListener("show-auth-modal", handler);
  }, []);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    if (!isAuthenticated) {
      if (guestCount >= 4) { setShowAuthModal(true); return; }
      const newCount = guestCount + 1;
      setGuestCount(newCount);
      localStorage.setItem("nova_guest_count", newCount.toString());
      if (newCount >= 4) setShowAuthModal(true);
    }

    const userMsg = input.trim();
    setInput("");

    const now = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    const newMessages = [...messages, {
      role: "user" as const, content: userMsg, timestamp: now
    }];
    setMessages(newMessages);
    setIsLoading(true);

    try {
      const headers: Record<string, string> = { "Content-Type": "application/json" };
      if (isAuthenticated) {
        const validToken = await getValidToken();
        if (validToken) headers["Authorization"] = `Bearer ${validToken}`;
      }

      const response = await fetch("http://localhost:8000/api/chat/stream", {
        method: "POST",
        headers,
        body: JSON.stringify({
          message: userMsg,
          conversation_id: conversationId,
          stream: true,
        }),
      });

      if (response.status === 401) {
        logout();
        throw new Error("Session expired. Please sign in again.");
      }
      
      if (response.status === 403 || response.status === 404) {
        setConversationId(null);
        throw new Error("This conversation doesn't exist or belongs to a different account. Please refresh and try again.");
      }

      if (!response.ok) throw new Error("Backend error");

      const reader = response.body?.getReader();
      const decoder = new TextDecoder();
      let assistantContent = "";
      let currentResponseType = "explanation";
      
      isStreamingRef.current = true;

      setMessages([...newMessages, { role: "assistant" as const, content: "", timestamp: now, responseType: "explanation", isStreaming: true, isThinking: true }]);

      if (reader) {
        try {
          while (true) {
            const { done, value } = await reader.read();
            if (done) break;

            const chunk = decoder.decode(value);
            for (const line of chunk.split("\n")) {
              if (line.startsWith("data: ") && line.trim() !== "data: [DONE]") {
                try {
                  const rawJson = line.slice(6);
                  const data = JSON.parse(rawJson);
                  
                  // Metadata + Context
                  if (data.conversation_id && data.conversation_id !== conversationId) {
                    setConversationId(data.conversation_id);
                  }
                  if (data.type === "metadata" && data.response_type) {
                    currentResponseType = data.response_type;
                    setStreamingResponseType(data.response_type);
                  }

                  // 20-Phase normalized parser
                  const parsed = parseNovaEvent(rawJson);
                  if (parsed) {
                    // CRITICAL: Accumulate text OUTSIDE the setMessages updater.
                    // React 18 Strict Mode calls updater functions twice to detect side effects.
                    // Mutating assistantContent inside the updater causes the text to be doubled.
                    if (parsed.type === "text") {
                      if (data.is_revision) {
                        assistantContent = parsed.text;
                      } else {
                        assistantContent += parsed.text;
                      }
                    }

                    // Snapshot the accumulated value so the pure updater just reads it
                    const snapshotContent = assistantContent;

                    setMessages(prev => {
                      const updated = [...prev];
                      const last = updated[updated.length - 1];
                      if (!last || last.role !== "assistant") return updated;

                      if (parsed.type === "status") {
                        if (parsed.status === "error") {
                          last.blocks = [{ type: "callout", data: { intent: "error", text: parsed.message || `Something went wrong.` } }];
                          last.isThinking = false;
                        } else if (parsed.status === "thinking") {
                          last.isThinking = true;
                        } else if (parsed.status === "done") {
                          last.isThinking = false;
                        }
                      } else if (parsed.type === "text") {
                        // Pure read — no mutation here
                        last.content = snapshotContent;
                        last.isThinking = false;
                      } else if (parsed.type === "structured") {
                        last.blocks = parsed.blocks;
                        last.isThinking = false;
                      } else if (parsed.type === "sources") {
                        last.searchState = { status: "complete", sources: parsed.sources };
                      }
                      
                      last.responseType = currentResponseType;
                      updated[updated.length - 1] = { ...last };
                      return updated;
                    });
                  }
                  if (data.error) break; // End stream on error
                } catch (e) {
                  // Re-throw if it's our own error, otherwise ignore parse errors for partial chunks
                  if (e instanceof Error && e.message !== "Unexpected end of JSON input" && !e.message.includes("JSON")) {
                    throw e;
                  }
                }
              }
            }
          }
          // Mark streaming complete
          setMessages(prev => {
            const updated = [...prev];
            if (updated.length > 0) {
              updated[updated.length - 1] = { 
                ...updated[updated.length - 1], 
                isStreaming: false,
                isThinking: false 
              };
            }
            return updated;
          });
          // Notify sidebar to refresh conversations list
          window.dispatchEvent(new Event("nova-refresh-conversations"));
        } catch (error: any) {
          console.error("Chat Error:", error);
          setMessages(prev => {
            const updated = [...prev];
            if (updated.length > 0 && updated[updated.length - 1].role === "assistant") {
              updated[updated.length - 1] = {
                ...updated[updated.length - 1],
                isStreaming: false,
                isThinking: false,
                blocks: [{ type: "callout", data: { intent: "error", text: error.message || "Network error" } }]
              };
            }
            return updated;
          });
        }
      }
    } catch (error) {
      setMessages(prev => [
        ...prev,
        { role: "assistant" as const, content: "I had a connection issue. Try again?", timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) }
      ]);
    } finally {
      // Mark that we just finished streaming so the conversationId effect
      // skips the next DB reload (which would duplicate the rendered message).
      justStreamedRef.current = true;
      isStreamingRef.current = false;
      setIsLoading(false);
    }
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-[#0a0a0a] relative">
      {showAuthModal && (
        <AuthModal
          onClose={() => setShowAuthModal(false)}
          message="You've used your 4 free messages. Create a free account to keep chatting with NOVA."
        />
      )}

      {/* Clean minimal header */}
      <header className="h-14 border-b border-white/[0.05] flex items-center justify-between px-5 flex-shrink-0">
        <div className="flex items-center gap-2.5">
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-white/[0.04] border border-white/[0.06]">
            <Sparkles className="w-3.5 h-3.5 text-primary" />
            <span className="text-xs font-semibold text-white/70">NOVA</span>
          </div>
          {!isAuthenticated && (
            <span className="text-[10px] text-white/30 bg-white/[0.04] px-2 py-1 rounded-md border border-white/[0.06]">
              Guest · {4 - guestCount} messages left
            </span>
          )}
        </div>
        <div className="flex items-center gap-2">
          {!isAuthenticated && (
            <button
              onClick={() => setShowAuthModal(true)}
              className="px-3 py-1.5 text-xs font-semibold bg-primary text-white rounded-lg hover:bg-primary/90 transition-colors shadow-[0_0_12px_rgba(124,58,237,0.3)]"
            >
              Sign In
            </button>
          )}
        </div>
      </header>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto custom-scrollbar">
        <div className="max-w-3xl mx-auto px-4 py-6">
          {messages.length === 0 && !isLoading ? (
            <div className="flex flex-col items-center justify-center h-[50vh] text-center">
              <div className="w-16 h-16 rounded-2xl bg-primary/10 border border-primary/20 flex items-center justify-center mb-4">
                <Sparkles className="w-7 h-7 text-primary" />
              </div>
              <h2 className="text-2xl font-bold text-white mb-2">What can I help you with?</h2>
              <p className="text-white/30 text-sm max-w-md">Ask me anything — code, ideas, advice, facts, or just chat.</p>
            </div>
          ) : (
            <MessageList messages={messages} isLoading={isLoading} />
          )}
          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Input Area */}
      <div className="px-4 pb-5 pt-2 flex-shrink-0">
        <div className="max-w-3xl mx-auto">
          {/* File attachment feature removed per user request */}          <div className="relative rounded-2xl border border-white/[0.08] bg-[#1a1a1a] shadow-2xl focus-within:border-white/20 transition-colors">
            <textarea
              value={input}
              onChange={(e) => {
                setInput(e.target.value);
                e.target.style.height = "auto";
                e.target.style.height = Math.min(e.target.scrollHeight, 200) + "px";
              }}
              placeholder="Message NOVA..."
              className="w-full bg-transparent resize-none border-none focus:outline-none text-white placeholder:text-white/25 py-4 px-4 pr-28 text-sm leading-relaxed custom-scrollbar"
              rows={1}
              style={{ minHeight: "56px", maxHeight: "200px" }}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  handleSend();
                }
              }}
            />
            <div className="absolute right-3 bottom-3 flex items-center gap-1.5">
              {/* FilePicker removed per user request */}

              <button
                onClick={() => setIsRecording(!isRecording)}
                className={clsx(
                  "p-2 rounded-lg transition-colors",
                  isRecording
                    ? "text-red-400 bg-red-400/10 animate-pulse"
                    : "text-white/25 hover:text-white/60 hover:bg-white/[0.05]"
                )}
              >
                <Mic className="w-4 h-4" />
              </button>
              <button
                onClick={handleSend}
                disabled={!input.trim() || isLoading}
                className={clsx(
                  "p-2 rounded-lg transition-all duration-200",
                  (input.trim()) && !isLoading
                    ? "bg-white text-black hover:bg-white/90 shadow-md"
                    : "bg-white/[0.06] text-white/20 cursor-not-allowed"
                )}
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </div>
          <p className="text-center mt-2 text-[10px] text-white/20">
            NOVA can make mistakes. Double-check important info.
          </p>
        </div>
      </div>
    </div>
  );
}
