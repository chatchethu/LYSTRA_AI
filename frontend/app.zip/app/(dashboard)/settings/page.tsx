"use client";

import { useState } from "react";
import { User, Cpu, Database, Wrench, Mic, Palette, Key, Save } from "lucide-react";
import clsx from "clsx";

export default function SettingsPage() {
  const [activeTab, setActiveTab] = useState("ai");

  const tabs = [
    { id: "profile", label: "Profile", icon: User },
    { id: "ai", label: "AI Settings", icon: Cpu },
    { id: "memory", label: "Memory", icon: Database },
    { id: "tools", label: "Tools", icon: Wrench },
    { id: "voice", label: "Voice", icon: Mic },
    { id: "appearance", label: "Appearance", icon: Palette },
    { id: "api", label: "API Keys", icon: Key },
  ];

  return (
    <div className="flex-1 overflow-y-auto custom-scrollbar flex">
      {/* Settings Sidebar */}
      <div className="w-64 border-r border-white/5 p-6 hidden md:block">
        <h2 className="text-xl font-bold text-white mb-6">Settings</h2>
        <nav className="space-y-1">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={clsx(
                "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors",
                activeTab === tab.id
                  ? "bg-primary/20 text-primary"
                  : "text-text-secondary hover:bg-white/5 hover:text-white"
              )}
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
            </button>
          ))}
        </nav>
      </div>

      {/* Settings Content */}
      <div className="flex-1 p-6 md:p-10 max-w-3xl">
        {/* Mobile Nav */}
        <div className="md:hidden mb-8 overflow-x-auto hide-scrollbar flex gap-2">
           {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={clsx(
                "flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-colors border",
                activeTab === tab.id
                  ? "bg-primary/20 text-primary border-primary/30"
                  : "bg-black/30 text-text-secondary border-white/5"
              )}
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
            </button>
          ))}
        </div>

        {activeTab === "ai" && (
          <div className="space-y-8 animate-fadeIn">
            <div>
              <h3 className="text-2xl font-bold text-white mb-2">AI Settings</h3>
              <p className="text-text-muted">Configure default model and behavior.</p>
            </div>

            <div className="glass-card p-6 space-y-6">
              <div className="space-y-2">
                <label className="text-sm font-medium text-white">Default Model</label>
                <select className="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-2.5 text-sm text-white focus:outline-none focus:border-primary/50">
                  <option value="gpt-4-turbo">GPT-4 Turbo</option>
                  <option value="claude-3-opus">Claude 3 Opus</option>
                  <option value="llama-3">Llama 3 70B</option>
                </select>
              </div>

              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <label className="text-sm font-medium text-white">Temperature (Creativity)</label>
                  <span className="text-sm text-primary font-mono bg-primary/10 px-2 py-0.5 rounded">0.7</span>
                </div>
                <input type="range" min="0" max="2" step="0.1" defaultValue="0.7" className="w-full accent-primary" />
                <div className="flex justify-between text-xs text-text-muted">
                  <span>Precise</span>
                  <span>Creative</span>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-white">System Prompt</label>
                <textarea 
                  rows={4}
                  className="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-3 text-sm text-white focus:outline-none focus:border-primary/50 resize-none font-mono"
                  defaultValue="You are a helpful Personal AI assistant. Be concise."
                />
              </div>
            </div>

            <div className="flex justify-end">
              <button className="bg-primary hover:bg-primary/90 text-white px-6 py-2.5 rounded-lg font-medium flex items-center gap-2 transition-all">
                <Save className="w-4 h-4" /> Save Changes
              </button>
            </div>
          </div>
        )}

        {activeTab !== "ai" && (
          <div className="flex flex-col items-center justify-center h-64 glass-card p-6 border-dashed border-white/10">
            <Cpu className="w-12 h-12 text-text-muted mb-4 opacity-50" />
            <h3 className="text-lg font-medium text-text-secondary">Section under construction</h3>
            <p className="text-sm text-text-muted text-center mt-2 max-w-sm">
              The {tabs.find(t => t.id === activeTab)?.label} settings are being updated. Check back soon.
            </p>
          </div>
        )}

      </div>
    </div>
  );
}
