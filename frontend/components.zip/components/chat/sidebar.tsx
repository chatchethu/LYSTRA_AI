import { useEffect, useState } from "react";
import { MessageSquare, Plus, MoreHorizontal, Trash2, BrainCircuit } from "lucide-react";
import { useAuth } from "@/components/auth/AuthProvider";
import clsx from "clsx";
import Link from "next/link";

interface Conversation {
  id: string;
  title: string;
  updated_at: string;
}

interface SidebarProps {
  currentConversationId: string | null;
  onSelectConversation: (id: string | null) => void;
  isOpen: boolean;
}

export function ChatSidebar({ currentConversationId, onSelectConversation, isOpen }: SidebarProps) {
  const { isAuthenticated, token, isAuthLoaded } = useAuth();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const fetchConversations = async () => {
    if (!isAuthenticated || !token) return;
    setIsLoading(true);
    try {
      const res = await fetch("http://localhost:8000/api/conversations", {
        headers: {
          "Authorization": `Bearer ${token}`
        }
      });
      if (res.ok) {
        const data = await res.json();
        setConversations(data);
      }
    } catch (error) {
      console.error("Failed to fetch conversations:", error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (!isAuthLoaded) return; // Don't fetch until auth has hydrated
    fetchConversations();
  }, [isAuthenticated, token, isAuthLoaded, currentConversationId]); // Refetch when current conv changes (new conv created)

  const handleDelete = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!confirm("Delete this conversation?")) return;
    
    try {
      await fetch(`http://localhost:8000/api/conversations/${id}`, {
        method: "DELETE",
        headers: { "Authorization": `Bearer ${token}` }
      });
      if (currentConversationId === id) {
        onSelectConversation(null);
      } else {
        fetchConversations();
      }
    } catch (error) {
      console.error("Failed to delete conversation:", error);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="w-64 h-full bg-[#05080f] border-r border-white/5 flex flex-col flex-shrink-0 transition-all duration-300">
      <div className="p-4 flex flex-col gap-4">
        <button 
          onClick={() => onSelectConversation(null)}
          className="w-full flex items-center gap-2 px-4 py-3 bg-white/5 hover:bg-white/10 rounded-xl text-sm font-medium text-white transition-colors border border-white/5"
        >
          <Plus className="w-4 h-4" />
          New Chat
        </button>
        
        <Link href="/brain" className="w-full flex items-center justify-between px-4 py-3 bg-primary/10 hover:bg-primary/20 rounded-xl text-sm font-medium text-primary transition-colors border border-primary/20">
          <div className="flex items-center gap-2">
            <BrainCircuit className="w-4 h-4" />
            NOVA Brain
          </div>
        </Link>
      </div>

      <div className="flex-1 overflow-y-auto px-2 pb-4 custom-scrollbar">
        <div className="text-xs font-semibold text-text-muted px-2 mb-2 uppercase tracking-wider">
          History
        </div>
        
        {!isAuthenticated ? (
          <div className="text-xs text-text-muted px-2 italic">
            Sign in to save chat history.
          </div>
        ) : conversations.length === 0 ? (
          <div className="text-xs text-text-muted px-2 italic">
            No conversations yet.
          </div>
        ) : (
          <div className="flex flex-col gap-1">
            {conversations.map(conv => (
              <div 
                key={conv.id}
                onClick={() => onSelectConversation(conv.id)}
                className={clsx(
                  "group flex items-center justify-between px-3 py-2 rounded-lg cursor-pointer transition-colors text-sm",
                  currentConversationId === conv.id 
                    ? "bg-primary/20 text-white" 
                    : "text-text-muted hover:bg-white/5 hover:text-white"
                )}
              >
                <div className="flex items-center gap-2 overflow-hidden">
                  <MessageSquare className="w-4 h-4 flex-shrink-0" />
                  <span className="truncate">{conv.title || "New Conversation"}</span>
                </div>
                <button 
                  onClick={(e) => handleDelete(conv.id, e)}
                  className="opacity-0 group-hover:opacity-100 p-1 hover:text-error transition-all"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
      
      {isAuthenticated && (
        <div className="p-4 border-t border-white/5 mt-auto">
          {/* User profile snippet could go here */}
        </div>
      )}
    </div>
  );
}
