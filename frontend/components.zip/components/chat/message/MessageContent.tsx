import React from "react";
import { ResponseRenderer } from "../response/ResponseRenderer";

interface MessageContentProps {
  content: string;
  responseType?: string;
  isStreaming?: boolean;
}

export function MessageContent({ content, responseType = "explanation", isStreaming = false }: MessageContentProps) {
  return (
    <div className="min-w-0 w-full">
      <ResponseRenderer
        content={content}
        responseType={responseType}
        isStreaming={isStreaming}
      />
    </div>
  );
}
