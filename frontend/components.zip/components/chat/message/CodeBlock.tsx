import React, { useState } from "react";
import { Prism as SyntaxHighlighter } from "react-syntax-highlighter";
import { vscDarkPlus } from "react-syntax-highlighter/dist/esm/styles/prism";
import { Check, Copy } from "lucide-react";

interface CodeBlockProps {
  language: string;
  value: string;
}

export function CodeBlock({ language, value }: CodeBlockProps) {
  const [isCopied, setIsCopied] = useState(false);

  const copyToClipboard = () => {
    navigator.clipboard.writeText(value);
    setIsCopied(true);
    setTimeout(() => {
      setIsCopied(false);
    }, 2000);
  };

  return (
    <div className="rounded-lg overflow-hidden my-4 border border-white/10 bg-[#1E1E1E] shadow-xl">
      <div className="flex items-center justify-between px-4 py-2 bg-black/60 border-b border-white/10">
        <span className="text-xs font-mono text-text-secondary uppercase tracking-wider">{language}</span>
        <button
          onClick={copyToClipboard}
          className="flex items-center gap-1.5 text-xs text-text-muted hover:text-text-primary transition-colors bg-white/5 hover:bg-white/10 px-2 py-1 rounded"
        >
          {isCopied ? (
            <>
              <Check className="w-3.5 h-3.5 text-success" />
              <span className="text-success">Copied!</span>
            </>
          ) : (
            <>
              <Copy className="w-3.5 h-3.5" />
              <span>Copy</span>
            </>
          )}
        </button>
      </div>
      <div className="overflow-x-auto custom-scrollbar">
        <SyntaxHighlighter
          style={vscDarkPlus as any}
          language={language}
          PreTag="div"
          customStyle={{ margin: 0, background: "transparent", padding: "1rem" }}
        >
          {value}
        </SyntaxHighlighter>
      </div>
    </div>
  );
}
