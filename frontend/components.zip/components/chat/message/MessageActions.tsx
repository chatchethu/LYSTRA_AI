import React, { useState } from "react";
import { Copy, Check, RotateCcw, Edit2, MoreHorizontal } from "lucide-react";
import clsx from "clsx";

interface MessageActionsProps {
  role: "user" | "assistant";
  content: string;
}

export function MessageActions({ role, content }: MessageActionsProps) {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className={clsx(
      "flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity",
      role === "user" ? "flex-row-reverse" : "flex-row"
    )}>
      {role === "assistant" && (
        <>
          <button 
            onClick={handleCopy}
            className="p-1.5 hover:bg-white/10 rounded-md text-text-muted hover:text-text-primary transition-colors"
            title="Copy"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-success" /> : <Copy className="w-3.5 h-3.5" />}
          </button>
          <button 
            className="p-1.5 hover:bg-white/10 rounded-md text-text-muted hover:text-text-primary transition-colors"
            title="Retry"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
          <button 
            className="p-1.5 hover:bg-white/10 rounded-md text-text-muted hover:text-text-primary transition-colors"
            title="More"
          >
            <MoreHorizontal className="w-3.5 h-3.5" />
          </button>
        </>
      )}
      
      {role === "user" && (
        <>
          <button 
            className="p-1.5 hover:bg-white/10 rounded-md text-text-muted hover:text-text-primary transition-colors"
            title="Edit"
          >
            <Edit2 className="w-3.5 h-3.5" />
          </button>
          <button 
            className="p-1.5 hover:bg-white/10 rounded-md text-text-muted hover:text-text-primary transition-colors"
            title="More"
          >
            <MoreHorizontal className="w-3.5 h-3.5" />
          </button>
        </>
      )}
    </div>
  );
}
