"use client";

import React from "react";
import { MessageActions } from "./MessageActions";
import { MessageContent } from "./MessageContent";
import { Sparkles, Check, Wrench, Search, Globe, AlertCircle } from "lucide-react";
import clsx from "clsx";

import { BlockRenderer, UIBlock } from "@/components/response/BlockRenderer";

export interface SearchSource {
  title: string;
  url: string;
  domain: string;
}

export interface AssistantMessageProps {
  content: string;
  blocks?: UIBlock[];
  timestamp?: string;
  toolCalls?: { name: string; status: string; duration: string }[];
  isThinking?: boolean;
  responseType?: string;
  isStreaming?: boolean;
  searchState?: {
    status: "searching" | "complete" | "error";
    query?: string;
    sources?: SearchSource[];
  };
}

// Extract readable plain text from blocks for copy/actions
function blocksToPlainText(blocks: UIBlock[]): string {
  return blocks
    .map((b) => {
      const d = b.data || {};
      switch (b.type) {
        case "text":     return d.content || "";
        case "heading":  return d.text || "";
        case "list":     return (d.items || []).join("\n");
        case "callout":  return d.text || d.message || "";
        case "code":     return d.code || d.content || "";
        default:         return "";
      }
    })
    .filter(Boolean)
    .join("\n\n");
}

export function AssistantMessage({
  content,
  blocks,
  timestamp,
  toolCalls,
  isThinking,
  searchState,
  responseType = "explanation",
  isStreaming = false,
}: AssistantMessageProps) {
  // Decide what to render
  const hasValidBlocks = Array.isArray(blocks) && blocks.length > 0;
  const hasContent = content && content.trim().length > 0;
  // Show thinking animation when: explicitly thinking OR streaming with no content/blocks yet
  const isEmptyStream = isThinking || (isStreaming && !hasContent && !hasValidBlocks);

  // Text for copy button — prefer blocks-derived text, fall back to raw content
  const copyableText = hasValidBlocks ? blocksToPlainText(blocks!) : content;

  return (
    <div className="flex w-full justify-start group mb-6">
      <div className="w-full flex gap-3 relative">
        {/* Avatar — glows and floats while thinking */}
        <div
          className={clsx(
            "w-7 h-7 rounded-full flex items-center justify-center border shrink-0 mt-0.5 transition-all duration-500",
            isEmptyStream
              ? "bg-primary/30 border-primary/60 shadow-[0_0_18px_4px_rgba(124,58,237,0.45)] animate-bounce"
              : "bg-primary/15 border-primary/20"
          )}
        >
          <Sparkles
            className={clsx(
              "w-3.5 h-3.5 text-primary transition-all duration-300",
              isEmptyStream && "animate-pulse scale-110"
            )}
          />
        </div>

        <div className="flex-1 flex flex-col gap-2 min-w-0">
          {/* Tool Calls */}
          {toolCalls && toolCalls.length > 0 && (
            <div className="flex flex-wrap gap-2 mb-1">
              {toolCalls.map((tool, i) => (
                <div
                  key={i}
                  className="flex items-center gap-2 text-xs bg-black/40 rounded-md px-2.5 py-1.5 border border-white/5 w-fit"
                >
                  <Wrench className="w-3 h-3 text-primary" />
                  <span className="font-mono text-white/60">{tool.name}</span>
                  <span className="text-[10px] text-white/40">{tool.duration}</span>
                  {tool.status === "success" && <Check className="w-3 h-3 text-green-400 ml-1" />}
                </div>
              ))}
            </div>
          )}

          {/* Web Search State */}
          {searchState && (
            <div className="flex items-center gap-2 text-sm text-white/50 mb-1 bg-white/5 w-fit px-3 py-1.5 rounded-lg border border-white/5">
              {searchState.status === "searching" && (
                <>
                  <Search className="w-3.5 h-3.5 animate-pulse text-primary" />
                  <span>
                    Searching the web
                    {searchState.query && (
                      <span className="italic"> for &ldquo;{searchState.query}&rdquo;</span>
                    )}
                    …
                  </span>
                </>
              )}
              {searchState.status === "complete" && (
                <>
                  <Check className="w-3.5 h-3.5 text-green-400" />
                  <span>{searchState.sources?.length || 0} relevant sources found</span>
                </>
              )}
              {searchState.status === "error" && (
                <>
                  <AlertCircle className="w-3.5 h-3.5 text-orange-400" />
                  <span>Search failed, answering from memory</span>
                </>
              )}
            </div>
          )}

          {/* Main content area */}
          <div className="text-white/90">
            {isEmptyStream ? (
              /* Thinking: just the pulsing avatar icon — no text */
              <div className="h-6" />
            ) : hasValidBlocks ? (
              /* Dynamic JSON blocks */
              <div className="flex flex-col">
                {blocks!.map((b, i) => (
                  <BlockRenderer key={b.id ?? i} block={b} />
                ))}
              </div>
            ) : (
              /* Legacy markdown fallback */
              <MessageContent
                content={content}
                responseType={responseType}
                isStreaming={isStreaming}
              />
            )}
          </div>

          {/* Search sources */}
          {searchState?.status === "complete" &&
            searchState.sources &&
            searchState.sources.length > 0 && (
              <div className="mt-4">
                <div className="text-xs font-semibold text-white/40 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                  <Globe className="w-3.5 h-3.5" /> Sources
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                  {searchState.sources.map((source, i) => (
                    <a
                      key={i}
                      href={source.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex flex-col gap-1 p-3 rounded-xl bg-black/30 border border-white/5 hover:border-white/20 hover:bg-white/5 transition-all group/source"
                    >
                      <span className="text-sm font-medium text-white/80 line-clamp-1 group-hover/source:text-primary transition-colors">
                        {source.title}
                      </span>
                      <span className="text-[10px] text-white/40 truncate">{source.domain}</span>
                    </a>
                  ))}
                </div>
              </div>
            )}

          {/* Actions + timestamp */}
          <div className="flex items-center gap-3 mt-2">
            <MessageActions role="assistant" content={copyableText} />
            {timestamp && (
              <span className="text-[10px] text-white/30 opacity-0 group-hover:opacity-100 transition-opacity">
                {timestamp}
              </span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
