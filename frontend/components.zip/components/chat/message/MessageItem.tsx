import React from "react";
import { UserMessage } from "./UserMessage";
import { AssistantMessage } from "./AssistantMessage";

interface MessageItemProps {
  role: "user" | "assistant" | "system";
  content: string;
  timestamp?: string;
  toolCalls?: { name: string; status: string; duration: string }[];
  isThinking?: boolean;
  responseType?: string;
  isStreaming?: boolean;
  searchState?: {
    status: "searching" | "complete" | "error";
    query?: string;
    sources?: any[];
  };
  attachedFile?: {
    filename: string;
    type: string;
  };
  blocks?: any[];
}

export function MessageItem(props: MessageItemProps) {
  if (props.role === "user") {
    return <UserMessage {...props} />;
  }

  if (props.role === "assistant" || props.role === "system") {
    return <AssistantMessage {...props} />;
  }

  return null;
}
