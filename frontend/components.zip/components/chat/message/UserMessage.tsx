import React from "react";
import { MessageContent } from "./MessageContent";
import { FileText, Image as ImageIcon } from "lucide-react";

interface UserMessageProps {
  content: string;
  timestamp?: string;
  attachedFile?: {
    filename: string;
    type: "image" | "pdf" | "document" | string;
  };
}

export function UserMessage({ content, timestamp, attachedFile }: UserMessageProps) {
  return (
    <div className="flex w-full justify-end group mb-6">
      <div className="max-w-[80%] flex flex-col gap-1 items-end">
        {/* File attachment feature removed per user request */}
        <div className="px-4 py-3 rounded-2xl rounded-tr-sm bg-[#2d2d2d] text-white/90 text-sm leading-relaxed break-words whitespace-pre-wrap">
          {content}
        </div>
        {timestamp && (
          <span className="text-[10px] text-white/20 opacity-0 group-hover:opacity-100 transition-opacity">
            {timestamp}
          </span>
        )}
      </div>
    </div>
  );
}
