import React from "react";
import { MessageItem } from "./MessageItem";

interface Message {
  role: "user" | "assistant" | "system";
  content: string;
  timestamp?: string;
  toolCalls?: { name: string; status: string; duration: string }[];
  responseType?: string;
  isStreaming?: boolean;
  isThinking?: boolean;
  searchState?: {
    status: "searching" | "complete" | "error";
    query?: string;
    sources?: any[];
  };
  attachedFile?: {
    filename: string;
    type: string;
  };
  blocks?: any[];
}

interface MessageListProps {
  messages: Message[];
  isLoading?: boolean;
}

export function MessageList({ messages, isLoading }: MessageListProps) {
  return (
    <div className="max-w-3xl mx-auto flex flex-col gap-6 py-4">
      {messages.map((msg, i) => (
        <MessageItem key={i} {...msg} />
      ))}

      {/* Show standalone thinking indicator only if the last message is NOT already an assistant bubble */}
      {isLoading && messages[messages.length - 1]?.role === "user" && (
        <MessageItem role="assistant" content="" isThinking={true} />
      )}
    </div>
  );
}
