import React from "react";
import { Copy, Check, Wrench } from "lucide-react";
import clsx from "clsx";
import { ResponseRenderer } from "./response/ResponseRenderer";

interface MessageBubbleProps {
  role: "user" | "assistant" | "system";
  content: string;
  timestamp?: string;
  toolCalls?: { name: string; status: string; duration: string }[];
  responseType?: string;
  isStreaming?: boolean;
}

export function MessageBubble({
  role,
  content,
  timestamp,
  toolCalls,
  responseType = "explanation",
  isStreaming = false,
}: MessageBubbleProps) {
  const isUser = role === "user";
  const [copied, setCopied] = React.useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className={clsx("flex w-full mb-6", isUser ? "justify-end" : "justify-start")}>
      <div className={clsx(
        "max-w-[82%] flex flex-col gap-2 relative group",
        isUser ? "items-end" : "items-start"
      )}>
        <div className={clsx(
          "px-5 py-4 rounded-2xl animate-fadeIn shadow-lg",
          isUser
            ? "bg-gradient-to-br from-primary to-accent text-white rounded-tr-sm"
            : "bg-[#141414] text-text-primary rounded-tl-sm border border-white/[0.06]"
        )}>
          {/* Tool calls indicator */}
          {!isUser && toolCalls && toolCalls.length > 0 && (
            <div className="mb-3 space-y-2">
              {toolCalls.map((tool, i) => (
                <div key={i} className="flex items-center gap-2 text-xs bg-black/40 rounded px-2 py-1.5 border border-white/5 w-fit">
                  <Wrench className="w-3 h-3 text-primary" />
                  <span className="font-mono text-text-secondary">{tool.name}</span>
                  <span className="text-[10px] text-text-muted">{tool.duration}</span>
                  {tool.status === "success" && <Check className="w-3 h-3 text-success ml-1" />}
                </div>
              ))}
            </div>
          )}

          {/* Message content */}
          <div className="min-w-0">
            {isUser ? (
              // User messages: plain text, no Markdown processing
              <p className="text-sm md:text-[15px] leading-relaxed whitespace-pre-wrap break-words">
                {content}
              </p>
            ) : content === "" ? (
              // Typing indicator
              <span className="flex items-center gap-1.5 py-1">
                <span className="w-2 h-2 rounded-full bg-primary animate-bounce" style={{ animationDelay: "0ms" }} />
                <span className="w-2 h-2 rounded-full bg-primary animate-bounce" style={{ animationDelay: "150ms" }} />
                <span className="w-2 h-2 rounded-full bg-primary animate-bounce" style={{ animationDelay: "300ms" }} />
              </span>
            ) : (
              // AI responses: full structured renderer
              <ResponseRenderer
                content={content}
                responseType={responseType}
                isStreaming={isStreaming}
              />
            )}
          </div>
        </div>

        {/* Timestamp + copy button */}
        <div className={clsx(
          "flex items-center gap-2 text-xs text-text-muted opacity-0 group-hover:opacity-100 transition-opacity",
          isUser ? "flex-row-reverse" : "flex-row"
        )}>
          <span>{timestamp || new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</span>
          {!isUser && (
            <button
              onClick={handleCopy}
              className="hover:text-text-primary transition-colors p-1"
              title="Copy message"
            >
              {copied
                ? <Check className="w-3.5 h-3.5 text-success" />
                : <Copy className="w-3.5 h-3.5" />
              }
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
