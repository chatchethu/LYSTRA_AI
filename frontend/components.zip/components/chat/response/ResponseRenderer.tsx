"use client";

/**
 * ResponseRenderer — NOVA AI (Phase 9-11)
 *
 * Top-level renderer that takes a Markdown string + responseType and
 * renders it with proper visual hierarchy using custom block components.
 * Drop-in replacement for the bare <ReactMarkdown> in MessageBubble.
 */

import React, { useState, useCallback } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { Prism as SyntaxHighlighter } from "react-syntax-highlighter";
import { vscDarkPlus } from "react-syntax-highlighter/dist/esm/styles/prism";
import { Copy, Check, ChevronRight } from "lucide-react";

// ── Response type → visual theme ─────────────────────────────────────────────
const TYPE_BADGE: Record<string, { label: string; color: string }> = {
  project_plan:    { label: "Project Plan",    color: "bg-purple-500/20 text-purple-300 border-purple-500/30" },
  how_to:         { label: "How-To Guide",     color: "bg-blue-500/20 text-blue-300 border-blue-500/30" },
  troubleshooting:{ label: "Troubleshooting",  color: "bg-red-500/20 text-red-300 border-red-500/30" },
  comparison:     { label: "Comparison",       color: "bg-amber-500/20 text-amber-300 border-amber-500/30" },
  coding:         { label: "Code",             color: "bg-green-500/20 text-green-300 border-green-500/30" },
  research:       { label: "Research",         color: "bg-cyan-500/20 text-cyan-300 border-cyan-500/30" },
  explanation:    { label: "Explanation",      color: "bg-indigo-500/20 text-indigo-300 border-indigo-500/30" },
  brainstorm:     { label: "Brainstorm",       color: "bg-pink-500/20 text-pink-300 border-pink-500/30" },
  summary:        { label: "Summary",          color: "bg-slate-500/20 text-slate-300 border-slate-500/30" },
  list:           { label: "List",             color: "bg-teal-500/20 text-teal-300 border-teal-500/30" },
};

// ── Callout detection ─────────────────────────────────────────────────────────
// Parses > [!NOTE], > [!TIP], > [!WARNING], > [!IMPORTANT], > [!CAUTION] syntax
const CALLOUT_STYLES: Record<string, { icon: string; border: string; bg: string; label: string }> = {
  NOTE:      { icon: "ℹ️", border: "border-l-blue-400",   bg: "bg-blue-500/10",   label: "Note" },
  TIP:       { icon: "💡", border: "border-l-green-400",  bg: "bg-green-500/10",  label: "Tip" },
  WARNING:   { icon: "⚠️", border: "border-l-yellow-400", bg: "bg-yellow-500/10", label: "Warning" },
  IMPORTANT: { icon: "📌", border: "border-l-purple-400", bg: "bg-purple-500/10", label: "Important" },
  CAUTION:   { icon: "🚨", border: "border-l-red-400",    bg: "bg-red-500/10",    label: "Caution" },
  ERROR:     { icon: "❌", border: "border-l-red-500",    bg: "bg-red-500/15",    label: "Error" },
  SUCCESS:   { icon: "✅", border: "border-l-green-500",  bg: "bg-green-500/15",  label: "Success" },
};

interface ResponseRendererProps {
  content: string;
  responseType?: string;
  isStreaming?: boolean;
}

export function ResponseRenderer({ content, responseType = "explanation", isStreaming = false }: ResponseRendererProps) {
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  const handleCopyCode = useCallback((code: string, id: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(id);
    setTimeout(() => setCopiedCode(null), 2000);
  }, []);

  const badge = TYPE_BADGE[responseType];
  const showBadge = badge && !["conversational", "quick_answer"].includes(responseType);
  const isEmpty = !content || content.trim() === "";

  // While streaming hasn't produced any content yet → show bouncing dots only
  if (isStreaming && isEmpty) {
    return (
      <span className="flex items-center gap-1.5 py-2 pl-1">
        <span className="w-1.5 h-1.5 rounded-full bg-white/60 animate-bounce" style={{ animationDelay: "0ms" }} />
        <span className="w-1.5 h-1.5 rounded-full bg-white/60 animate-bounce" style={{ animationDelay: "150ms" }} />
        <span className="w-1.5 h-1.5 rounded-full bg-white/60 animate-bounce" style={{ animationDelay: "300ms" }} />
      </span>
    );
  }

  if (isEmpty) return null;

  return (
    <div className="nova-response w-full">
      {/* Response type badge — only shown once content is present */}
      {showBadge && !isEmpty && (
        <div className={`inline-flex items-center gap-1.5 text-[10px] font-semibold px-2 py-0.5 rounded-full border mb-3 ${badge.color}`}>
          {badge.label}
        </div>
      )}

      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        components={{
          // ── Headings ──────────────────────────────────────────────────────
          h1({ children }) {
            return (
              <h1 className="text-2xl font-bold text-white mt-6 mb-3 pb-2 border-b border-white/10 first:mt-0">
                {children}
              </h1>
            );
          },
          h2({ children }) {
            return (
              <h2 className="text-lg font-semibold text-white/95 mt-5 mb-2 flex items-center gap-2">
                <span className="w-0.5 h-5 bg-primary rounded-full flex-shrink-0" />
                {children}
              </h2>
            );
          },
          h3({ children }) {
            return (
              <h3 className="text-base font-semibold text-white/80 mt-4 mb-1.5 pl-3 border-l-2 border-white/20">
                {children}
              </h3>
            );
          },

          // ── Paragraphs ────────────────────────────────────────────────────
          p({ children }) {
            return (
              <p className="text-[15px] text-white/85 leading-relaxed mb-3 last:mb-0">
                {children}
              </p>
            );
          },

          // ── Lists ─────────────────────────────────────────────────────────
          ul({ children }) {
            return (
              <ul className="space-y-1.5 my-3 ml-1">
                {children}
              </ul>
            );
          },
          ol({ children }) {
            return (
              <ol className="space-y-2 my-3 ml-1 list-none counter-reset-[step]">
                {children}
              </ol>
            );
          },
          li({ children, ordered, index }: any) {
            const isOrdered = ordered;
            return (
              <li className="flex items-start gap-2.5 text-[15px] text-white/85 leading-relaxed">
                {isOrdered ? (
                  <span className="flex-shrink-0 w-5 h-5 rounded-full bg-primary/20 border border-primary/30 flex items-center justify-center text-[10px] font-bold text-primary mt-0.5">
                    {(index ?? 0) + 1}
                  </span>
                ) : (
                  <ChevronRight className="w-3.5 h-3.5 text-primary flex-shrink-0 mt-1" />
                )}
                <span className="flex-1">{children}</span>
              </li>
            );
          },

          // ── Code ──────────────────────────────────────────────────────────
          code({ node, inline, className, children, ...props }: any) {
            const match = /language-(\w+)/.exec(className || "");
            const codeStr = String(children).replace(/\n$/, "");
            const codeId = `code-${codeStr.slice(0, 20)}`;

            if (!inline && match) {
              return (
                <div className="my-4 rounded-xl overflow-hidden border border-white/10 bg-[#0d1117] shadow-lg">
                  {/* Header bar */}
                  <div className="flex items-center justify-between px-4 py-2 bg-black/40 border-b border-white/10">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full bg-red-500/70" />
                      <div className="w-3 h-3 rounded-full bg-yellow-500/70" />
                      <div className="w-3 h-3 rounded-full bg-green-500/70" />
                      <span className="ml-2 text-xs font-mono text-white/40">{match[1]}</span>
                    </div>
                    <button
                      onClick={() => handleCopyCode(codeStr, codeId)}
                      className="flex items-center gap-1.5 text-xs text-white/40 hover:text-white/80 transition-colors px-2 py-0.5 rounded hover:bg-white/10"
                    >
                      {copiedCode === codeId
                        ? <><Check className="w-3 h-3 text-green-400" /> Copied</>
                        : <><Copy className="w-3 h-3" /> Copy</>
                      }
                    </button>
                  </div>
                  <SyntaxHighlighter
                    style={vscDarkPlus as any}
                    language={match[1]}
                    PreTag="div"
                    customStyle={{ margin: 0, background: "transparent", padding: "1rem", fontSize: "0.8125rem" }}
                    {...props}
                  >
                    {codeStr}
                  </SyntaxHighlighter>
                </div>
              );
            }
            return (
              <code className="bg-black/40 border border-white/10 rounded px-1.5 py-0.5 text-[#e06c75] font-mono text-[0.8em]" {...props}>
                {children}
              </code>
            );
          },

          // ── Tables ────────────────────────────────────────────────────────
          table({ children }) {
            return (
              <div className="my-4 overflow-x-auto rounded-xl border border-white/10">
                <table className="w-full text-sm border-collapse">{children}</table>
              </div>
            );
          },
          thead({ children }) {
            return <thead className="bg-white/5 border-b border-white/10">{children}</thead>;
          },
          tbody({ children }) {
            return <tbody className="divide-y divide-white/5">{children}</tbody>;
          },
          tr({ children }) {
            return <tr className="hover:bg-white/[0.03] transition-colors">{children}</tr>;
          },
          th({ children }) {
            return (
              <th className="px-4 py-2.5 text-left text-xs font-semibold text-white/60 uppercase tracking-wider">
                {children}
              </th>
            );
          },
          td({ children }) {
            return (
              <td className="px-4 py-2.5 text-[13px] text-white/80">
                {children}
              </td>
            );
          },

          // ── Blockquotes (callouts) ────────────────────────────────────────
          blockquote({ children }) {
            // Try to detect [!TYPE] callout syntax
            const text = String(children);
            const calloutMatch = text.match(/\[!(NOTE|TIP|WARNING|IMPORTANT|CAUTION|ERROR|SUCCESS)\]/i);

            if (calloutMatch) {
              const type = calloutMatch[1].toUpperCase();
              const style = CALLOUT_STYLES[type] || CALLOUT_STYLES.NOTE;
              const cleanContent = text.replace(/\[!.*?\]/, "").trim();

              return (
                <div className={`my-4 flex gap-3 p-4 rounded-xl border-l-4 ${style.border} ${style.bg}`}>
                  <span className="text-lg flex-shrink-0 mt-0.5">{style.icon}</span>
                  <div>
                    <div className="text-xs font-bold text-white/60 uppercase tracking-wider mb-1">{style.label}</div>
                    <div className="text-[13px] text-white/85 leading-relaxed">{cleanContent}</div>
                  </div>
                </div>
              );
            }

            return (
              <blockquote className="my-3 pl-4 border-l-2 border-primary/40 text-white/60 italic text-sm">
                {children}
              </blockquote>
            );
          },

          // ── Horizontal rule ───────────────────────────────────────────────
          hr() {
            return <hr className="my-5 border-white/10" />;
          },

          // ── Strong / Em ───────────────────────────────────────────────────
          strong({ children }) {
            return <strong className="font-semibold text-white">{children}</strong>;
          },
          em({ children }) {
            return <em className="italic text-white/70">{children}</em>;
          },

          // ── Links ─────────────────────────────────────────────────────────
          a({ href, children }) {
            return (
              <a
                href={href}
                target="_blank"
                rel="noopener noreferrer"
                className="text-primary hover:text-primary-light underline underline-offset-2 transition-colors"
              >
                {children}
              </a>
            );
          },
        }}
      >
        {content}
      </ReactMarkdown>

      {/* Streaming cursor */}
      {isStreaming && (
        <span className="inline-block w-0.5 h-4 bg-primary animate-pulse ml-0.5 align-middle" />
      )}
    </div>
  );
}
