"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import {
  Brain,
  Plus,
  Search,
  Trash2,
  MessageSquare,
  Settings,
  Activity,
  BrainCircuit,
  LogOut,
  LogIn,
  ChevronRight
} from "lucide-react";
import clsx from "clsx";
import { useAuth } from "@/components/auth/AuthProvider";

interface Conversation {
  id: string;
  title: string;
  updated_at: string;
}

interface SidebarProps {
  currentConversationId: string | null;
  onSelectConversation: (id: string | null) => void;
}

export function Sidebar({ currentConversationId, onSelectConversation }: SidebarProps) {
  const pathname = usePathname();
  const router = useRouter();
  const { isAuthenticated, token, user, logout } = useAuth();

  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [isLoadingConvs, setIsLoadingConvs] = useState(false);

  const fetchConversations = async () => {
    if (!isAuthenticated || !token) return;
    setIsLoadingConvs(true);
    try {
      const res = await fetch("http://localhost:8000/api/conversations", {
        headers: { "Authorization": `Bearer ${token}` }
      });
      if (res.status === 401) {
        logout();
        return;
      }
      if (res.ok) {
        const data = await res.json();
        setConversations(data);
      }
    } catch (e) {
      console.error("Failed to fetch conversations", e);
    } finally {
      setIsLoadingConvs(false);
    }
  };

  useEffect(() => {
    if (!isAuthenticated) {
      setConversations([]);
      return;
    }
    fetchConversations();
  }, [isAuthenticated, token, currentConversationId]);

  // Listen for explicit refresh requests (e.g. after a new message is sent)
  useEffect(() => {
    const handler = () => fetchConversations();
    window.addEventListener("nova-refresh-conversations", handler);
    return () => window.removeEventListener("nova-refresh-conversations", handler);
  }, [isAuthenticated, token]);

  const handleNewChat = () => {
    onSelectConversation(null);
    if (pathname !== "/chat") router.push("/chat");
  };

  const handleDelete = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!confirm("Delete this conversation?")) return;
    try {
      await fetch(`http://localhost:8000/api/conversations/${id}`, {
        method: "DELETE",
        headers: { "Authorization": `Bearer ${token}` }
      });
      if (currentConversationId === id) onSelectConversation(null);
      else fetchConversations();
    } catch (e) {
      console.error(e);
    }
  };

  const filteredConvs = conversations.filter(c =>
    (c.title || "New Conversation").toLowerCase().includes(searchQuery.toLowerCase())
  );

  const userInitials = user?.username?.slice(0, 2).toUpperCase() || user?.email?.slice(0, 2).toUpperCase() || "N";

  return (
    <aside className="w-[260px] h-screen bg-[#0f0f0f] flex flex-col border-r border-white/[0.06] shrink-0 relative z-20">
      {/* Logo */}
      <div className="p-4 flex items-center gap-2.5 border-b border-white/[0.06]">
        <div className="w-7 h-7 rounded-lg bg-primary/20 flex items-center justify-center text-primary border border-primary/30">
          <Brain className="w-4 h-4" />
        </div>
        <span className="text-base font-bold tracking-tight text-white">NOVA <span className="text-primary">AI</span></span>
      </div>

      {/* New Chat Button */}
      <div className="p-3">
        <button
          onClick={handleNewChat}
          className="w-full flex items-center gap-2 px-3 py-2 bg-white/[0.05] hover:bg-white/[0.09] rounded-lg text-sm font-medium text-white/80 hover:text-white transition-all border border-white/[0.06] group"
        >
          <Plus className="w-4 h-4 text-primary group-hover:rotate-90 transition-transform duration-300" />
          New Chat
          <span className="ml-auto text-[10px] text-white/20">Ctrl+N</span>
        </button>
      </div>

      {/* Chat History */}
      <div className="flex-1 overflow-y-auto px-3 pb-2 flex flex-col gap-1 custom-scrollbar">
        {isAuthenticated && (
          <>
            {/* Search */}
            <div className="relative mb-2">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-white/30" />
              <input
                type="text"
                placeholder="Search conversations..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="w-full bg-white/[0.04] border border-white/[0.06] rounded-lg pl-8 pr-3 py-1.5 text-xs focus:outline-none focus:border-primary/40 transition-colors placeholder:text-white/20 text-white/70"
              />
            </div>

            {/* Conversations List */}
            {isLoadingConvs ? (
              <div className="flex justify-center py-4">
                <div className="w-4 h-4 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
              </div>
            ) : filteredConvs.length === 0 ? (
              <div className="text-center py-6">
                <MessageSquare className="w-6 h-6 text-white/10 mx-auto mb-2" />
                <p className="text-xs text-white/20">No conversations yet</p>
              </div>
            ) : (
              <>
                <p className="text-[10px] font-semibold uppercase tracking-widest text-white/20 px-1 mb-1">History</p>
                {filteredConvs.map((conv) => (
                  <div
                    key={conv.id}
                    onClick={() => {
                      onSelectConversation(conv.id);
                      if (pathname !== "/chat") router.push("/chat");
                    }}
                    className={clsx(
                      "group flex items-center justify-between px-3 py-2 rounded-lg cursor-pointer transition-all text-sm",
                      currentConversationId === conv.id
                        ? "bg-primary/10 text-white border border-primary/20"
                        : "text-white/50 hover:bg-white/[0.05] hover:text-white/80"
                    )}
                  >
                    <div className="flex items-center gap-2 overflow-hidden min-w-0">
                      <MessageSquare className="w-3.5 h-3.5 flex-shrink-0 opacity-50" />
                      <span className="truncate text-xs">{conv.title || "New Conversation"}</span>
                    </div>
                    <button
                      onClick={(e) => handleDelete(conv.id, e)}
                      className="opacity-0 group-hover:opacity-100 p-1 hover:text-red-400 transition-all flex-shrink-0"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </>
            )}
          </>
        )}

        {!isAuthenticated && (
          <div className="text-center py-8 px-2">
            <MessageSquare className="w-8 h-8 text-white/10 mx-auto mb-3" />
            <p className="text-xs text-white/30 leading-relaxed">Sign in to save and view your chat history</p>
          </div>
        )}
      </div>

      {/* Bottom Nav Links */}
      <div className="border-t border-white/[0.06] p-3 space-y-1">
        <Link href="/brain" className={clsx(
          "flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-medium transition-all",
          pathname.startsWith("/brain") ? "bg-primary/10 text-primary" : "text-white/40 hover:text-white/70 hover:bg-white/[0.04]"
        )}>
          <BrainCircuit className="w-4 h-4" />
          NOVA Brain
        </Link>
        <Link href="/metrics" className={clsx(
          "flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-medium transition-all",
          pathname.startsWith("/metrics") ? "bg-primary/10 text-primary" : "text-white/40 hover:text-white/70 hover:bg-white/[0.04]"
        )}>
          <Activity className="w-4 h-4" />
          Metrics
        </Link>
        <Link href="/settings" className={clsx(
          "flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-medium transition-all",
          pathname.startsWith("/settings") ? "bg-primary/10 text-primary" : "text-white/40 hover:text-white/70 hover:bg-white/[0.04]"
        )}>
          <Settings className="w-4 h-4" />
          Settings
        </Link>
      </div>

      {/* User Profile Footer */}
      <div className="border-t border-white/[0.06] p-3">
        {isAuthenticated && user ? (
          <div className="flex items-center gap-2.5 px-2 py-1.5 rounded-lg hover:bg-white/[0.04] transition-colors group">
            <div className="w-7 h-7 rounded-full bg-gradient-to-br from-primary to-violet-500 flex items-center justify-center text-white font-bold text-xs flex-shrink-0">
              {userInitials}
            </div>
            <div className="flex flex-col min-w-0 flex-1">
              <span className="text-xs font-semibold text-white/80 truncate">{user.username || user.email}</span>
              <span className="text-[10px] text-white/30">Pro Account</span>
            </div>
            <button
              onClick={logout}
              title="Logout"
              className="opacity-0 group-hover:opacity-100 p-1 text-white/30 hover:text-red-400 transition-all"
            >
              <LogOut className="w-3.5 h-3.5" />
            </button>
          </div>
        ) : (
          <button
            onClick={() => window.dispatchEvent(new Event("show-auth-modal"))}
            className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-medium text-white/40 hover:text-white/70 hover:bg-white/[0.04] transition-all"
          >
            <LogIn className="w-4 h-4" />
            Sign In
          </button>
        )}
      </div>
    </aside>
  );
}
