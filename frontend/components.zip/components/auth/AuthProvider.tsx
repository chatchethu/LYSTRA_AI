"use client";

import React, { createContext, useContext, useState, useEffect, useRef, useCallback } from "react";

const API_BASE = "http://localhost:8000";

interface User {
  id: string;
  email: string;
  username: string;
}

interface AuthContextType {
  user: User | null;
  token: string | null;
  isAuthLoaded: boolean;
  isAuthenticated: boolean;
  login: (token: string, user: User, refreshToken?: string) => void;
  logout: () => void;
  /** Call this before every API request — silently refreshes if token is near expiry */
  getValidToken: () => Promise<string | null>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

/** Parse JWT payload without verifying signature (we trust our own backend) */
function parseJwtPayload(token: string): { exp?: number; sub?: string; email?: string } | null {
  try {
    const base64 = token.split(".")[1].replace(/-/g, "+").replace(/_/g, "/");
    return JSON.parse(atob(base64));
  } catch {
    return null;
  }
}

/** Returns true if the token expires within the next 5 minutes */
function isTokenExpiringSoon(token: string): boolean {
  const payload = parseJwtPayload(token);
  if (!payload?.exp) return true;
  const expiresInMs = payload.exp * 1000 - Date.now();
  return expiresInMs < 5 * 60 * 1000; // less than 5 minutes left
}

/** Returns true if token is already expired */
function isTokenExpired(token: string): boolean {
  const payload = parseJwtPayload(token);
  if (!payload?.exp) return true;
  return payload.exp * 1000 < Date.now();
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [isLoaded, setIsLoaded] = useState(false);
  const refreshingRef = useRef<Promise<string | null> | null>(null);

  // On mount, restore session from localStorage
  useEffect(() => {
    const storedToken = localStorage.getItem("nova_token");
    const storedUser = localStorage.getItem("nova_user");
    const storedRefresh = localStorage.getItem("nova_refresh_token");

    if (storedToken && storedUser) {
      try {
        const parsedUser = JSON.parse(storedUser);
        if (!isTokenExpired(storedToken)) {
          // Token still valid, use it
          setToken(storedToken);
          setUser(parsedUser);
        } else if (storedRefresh) {
          // Access token expired but refresh token exists — silently refresh
          silentRefresh(storedRefresh).then((newToken) => {
            if (!newToken) {
              // Refresh also failed, clear session
              clearSession();
            }
          });
        } else {
          // No refresh token, clear expired session
          clearSession();
        }
      } catch {
        clearSession();
      }
    }
    setIsLoaded(true);
  }, []);

  const clearSession = () => {
    setToken(null);
    setUser(null);
    localStorage.removeItem("nova_token");
    localStorage.removeItem("nova_user");
    localStorage.removeItem("nova_refresh_token");
    localStorage.removeItem("nova_active_conv");
  };

  const silentRefresh = useCallback(async (refreshToken: string): Promise<string | null> => {
    // Deduplicate concurrent refresh calls
    if (refreshingRef.current) return refreshingRef.current;

    refreshingRef.current = (async () => {
      try {
        const res = await fetch(`${API_BASE}/api/auth/refresh`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ refresh_token: refreshToken }),
        });

        if (!res.ok) {
          clearSession();
          return null;
        }

        const data = await res.json();
        const newToken: string = data.access_token;
        const newRefresh: string = data.refresh_token;
        const newUser: User | null = data.user || null;

        localStorage.setItem("nova_token", newToken);
        localStorage.setItem("nova_refresh_token", newRefresh);
        if (newUser) {
          localStorage.setItem("nova_user", JSON.stringify(newUser));
          setUser(newUser);
        }
        setToken(newToken);
        return newToken;
      } catch {
        clearSession();
        return null;
      } finally {
        refreshingRef.current = null;
      }
    })();

    return refreshingRef.current;
  }, []);

  /**
   * Returns a valid access token, silently refreshing if it's expiring soon.
   * All API callers should use this instead of reading `token` directly.
   */
  const getValidToken = useCallback(async (): Promise<string | null> => {
    const currentToken = localStorage.getItem("nova_token");
    const refreshToken = localStorage.getItem("nova_refresh_token");

    if (!currentToken) return null;

    if (isTokenExpiringSoon(currentToken) && refreshToken) {
      return await silentRefresh(refreshToken);
    }

    return currentToken;
  }, [silentRefresh]);

  const login = useCallback((newToken: string, newUser: User, refreshToken?: string) => {
    setToken(newToken);
    setUser(newUser);
    localStorage.setItem("nova_token", newToken);
    localStorage.setItem("nova_user", JSON.stringify(newUser));
    if (refreshToken) {
      localStorage.setItem("nova_refresh_token", refreshToken);
    }
  }, []);

  const logout = useCallback(() => {
    clearSession();
  }, []);

  // Proactive background refresh — checks every 4 minutes
  useEffect(() => {
    const interval = setInterval(async () => {
      const currentToken = localStorage.getItem("nova_token");
      const refreshToken = localStorage.getItem("nova_refresh_token");
      if (currentToken && refreshToken && isTokenExpiringSoon(currentToken)) {
        await silentRefresh(refreshToken);
      }
    }, 4 * 60 * 1000); // every 4 minutes

    return () => clearInterval(interval);
  }, [silentRefresh]);

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        isAuthLoaded: isLoaded,
        isAuthenticated: !!token && isLoaded,
        login,
        logout,
        getValidToken,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
